"use client"

import { useState } from "react"
import Link from "next/link"
import { Trash2, Plus, Minus, ChevronLeft } from "lucide-react"

interface CartItem {
  id: number
  name: string
  price: number
  quantity: number
  size: string
  color: string
  image: string
}

const SAMPLE_CART: CartItem[] = [
  {
    id: 1,
    name: "Premium Leather Jacket",
    price: 249.99,
    quantity: 1,
    size: "L",
    color: "Black",
    image: "/black-leather-men-jacket.jpg",
  },
  {
    id: 2,
    name: "Classic Denim Jeans",
    price: 99.99,
    quantity: 2,
    size: "32",
    color: "Dark Blue",
    image: "/dark-blue-denim-jeans.jpg",
  },
]

export default function CartPage() {
  const [cartItems, setCartItems] = useState<CartItem[]>(SAMPLE_CART)

  const updateQuantity = (id: number, newQuantity: number) => {
    if (newQuantity < 1) return
    setCartItems((items) => items.map((item) => (item.id === id ? { ...item, quantity: newQuantity } : item)))
  }

  const removeItem = (id: number) => {
    setCartItems((items) => items.filter((item) => item.id !== id))
  }

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const tax = subtotal * 0.1
  const shipping = subtotal > 100 ? 0 : 9.99
  const total = subtotal + tax + shipping

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background border-b border-border">
        <div className="max-w-2xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/shop" className="flex items-center gap-2 text-primary hover:opacity-80 transition-opacity">
            <ChevronLeft size={20} />
            <span className="text-sm font-medium">Continue Shopping</span>
          </Link>
          <h1 className="text-lg font-bold tracking-tight">PLANET T</h1>
          <div className="w-24" />
        </div>
      </header>

      {/* Cart Content */}
      <main className="max-w-2xl mx-auto px-4 py-8">
        <h2 className="text-2xl font-bold mb-6">Shopping Cart</h2>

        {cartItems.length > 0 ? (
          <div className="grid grid-cols-1 gap-8">
            {/* Cart Items */}
            <div className="space-y-4">
              {cartItems.map((item) => (
                <div
                  key={`${item.id}-${item.size}-${item.color}`}
                  className="flex gap-4 border border-border rounded-lg p-4"
                >
                  {/* Product Image */}
                  <div className="w-20 h-20 bg-secondary rounded-md overflow-hidden flex-shrink-0 flex items-center justify-center">
                    <img
                      src={item.image || "/placeholder.svg"}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Product Details */}
                  <div className="flex-1">
                    <h3 className="font-semibold mb-1">{item.name}</h3>
                    <p className="text-sm text-muted-foreground mb-2">
                      Size: {item.size} • Color: {item.color}
                    </p>
                    <p className="font-semibold text-accent">${item.price.toFixed(2)}</p>
                  </div>

                  {/* Quantity and Remove */}
                  <div className="flex flex-col items-end gap-3">
                    <button
                      onClick={() => removeItem(item.id)}
                      className="p-2 text-muted-foreground hover:text-destructive transition-colors"
                    >
                      <Trash2 size={18} />
                    </button>

                    {/* Quantity Selector */}
                    <div className="flex items-center gap-2 border border-border rounded-md">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="px-2 py-1 hover:bg-secondary transition-colors"
                      >
                        <Minus size={14} />
                      </button>
                      <span className="px-3 py-1 text-sm font-medium">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="px-2 py-1 hover:bg-secondary transition-colors"
                      >
                        <Plus size={14} />
                      </button>
                    </div>

                    {/* Item Total */}
                    <p className="font-bold text-lg">${(item.price * item.quantity).toFixed(2)}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Order Summary */}
            <div className="bg-secondary rounded-lg p-6 space-y-4">
              <h3 className="font-semibold text-lg mb-4">Order Summary</h3>

              <div className="space-y-3 border-b border-border pb-4">
                <div className="flex justify-between text-sm">
                  <span>Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Shipping</span>
                  <span className={shipping === 0 ? "text-accent font-semibold" : ""}>
                    {shipping === 0 ? "Free" : `$${shipping.toFixed(2)}`}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Tax (estimated)</span>
                  <span>${tax.toFixed(2)}</span>
                </div>
              </div>

              <div className="flex justify-between text-lg font-bold">
                <span>Total</span>
                <span>${total.toFixed(2)}</span>
              </div>

              {shipping === 0 && (
                <p className="text-xs text-accent bg-accent/10 rounded p-2">Free shipping on orders over $100!</p>
              )}

              <Link
                href="/checkout"
                className="block w-full bg-primary text-primary-foreground px-6 py-3 rounded-md font-semibold hover:opacity-90 transition-opacity text-center"
              >
                Proceed to Checkout
              </Link>
            </div>
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-muted-foreground mb-6">Your cart is empty</p>
            <Link
              href="/shop"
              className="inline-block bg-primary text-primary-foreground px-6 py-3 rounded-md font-semibold hover:opacity-90 transition-opacity"
            >
              Start Shopping
            </Link>
          </div>
        )}
      </main>
    </div>
  )
}
